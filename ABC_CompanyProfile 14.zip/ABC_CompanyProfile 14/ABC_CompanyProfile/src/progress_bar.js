document.addEventListener("DOMContentLoaded", function () {
  const readingProgressContainer = document.getElementById('reading-progress-container');
  const readingProgress = document.getElementById('reading-progress');
  const progressPercentage = document.getElementById('progress-percentage');

  // Calculate and update reading progress
  function updateReadingProgress() {
      const scrollPosition = window.scrollY;
      const totalHeight = document.body.scrollHeight - window.innerHeight;
      const progress = Math.round((scrollPosition / totalHeight) * 100);
      readingProgress.style.width = Math.min(100, progress) + '%';
      progressPercentage.textContent = Math.min(100, progress) + '%';
  }

  // Add scroll event listener to update progress
  window.addEventListener('scroll', updateReadingProgress);
});