const express = require('express');
const app = express();
const path = require('path');
const bodyParser = require('body-parser');
const session = require('express-session');
const { Form, Collection1 } = require('./mongo');

// Paths
const imagesPath = path.join(__dirname, '../images');
const templatePath = path.join(__dirname, '../templates');
const publicPath = path.join(__dirname, '../public');

// Express setup
app.use(session({ secret: 'your-secret-key', resave: true, saveUninitialized: true }));
app.use(bodyParser.urlencoded({ extended: false }));
app.set('view engine', 'hbs');
app.use(express.static(publicPath));
app.use(express.static(imagesPath));
app.use(express.json());
app.set('views', templatePath);
app.use(express.urlencoded({ extended: false }));

// Routes
app.get('/', (req, res) => {
  res.render('login');
});
app.get('/signup', (req, res) => {
  res.render('signup');
});

app.get('/templates/next', (req, res) => {
  res.render('next');
});

// ... Add routes for other pages ...

app.post('/submit-form', async (req, res) => {
  try {
    const formData = new Form(req.body);
    await formData.save();
    res.status(201).json({ message: 'Form submitted successfully' });
  } catch (error) {
    res.status(500).json({ message: 'Error submitting form', error });
  }
});

app.post('/signup', async (req, res) => {
  const data = {
    name: req.body.name,
    password: req.body.password
  };

  await Collection1.insertMany([data]);
  res.render('login');
});

app.post('/login', async (req, res) => {
  try {
      const check = await Collection1.findOne({ name: req.body.name });

      if (check.password === req.body.password) {
          res.status(201).render('index');
          // , { naming: `${req.body.password}+${req.body.name}` }
      } else {
          res.send('Incorrect password');
      }
  } catch (e) {
      res.send('Wrong details');
  }
});

app.post('/logout', (req, res) => {
  // Destroy the user session
  req.session.destroy((err) => {
      if (err) {
          console.error('Error destroying session:', err);
      } else {
          res.redirect('/'); // Redirect to the home page after logout
      }
  });
});
// ... Add other routes ...

// Start the server
const PORT = 3001;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
